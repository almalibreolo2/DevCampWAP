// 모듈 import
import {a, b, sum} from './math.js';


// sum 함수 호출해서 콘솔에 출력
console.log(sum(10, 20));

// app.js의 변수 콘솔에 출력
console.log(a);
console.log(b());
