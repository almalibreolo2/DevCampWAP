arr.forEach(function (data) {
	sum += data;
});

arr.forEach((data) => {
	sum += data;
});


// ES5
$('#addBtn').click(function () {
	//
});

// ES6
$('#addBtn').click(() => {

});

// ES5
function () {

}

// ES6
() => {

}

// https://babeljs.io/repl/
