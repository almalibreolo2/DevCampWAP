<template>
  <span>
    <h2>This is a Global Component<br />Navigation Header</h2>
  </span>
</template>

<script>
export default {
}
</script>

<style lang="css">
form {
  margin: 10px;
}
</style>
