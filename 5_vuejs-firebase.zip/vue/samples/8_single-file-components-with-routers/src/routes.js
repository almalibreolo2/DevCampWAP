import Main from './components/Main.vue'
import List from './components/List.vue'

export const routes = [
  { path: '/main', component: Main },
  { path: '/list', component: List }
  // 할일 #1
  // 컴포넌트를 하나 더 생성하여 router 에 등록해보세요.

];
