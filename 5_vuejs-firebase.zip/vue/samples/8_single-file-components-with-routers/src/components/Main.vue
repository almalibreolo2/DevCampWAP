<template lang="html">
  <div>
    <h3>Title</h3>
    <p>This is a paragraph</p>
  </div>
</template>
