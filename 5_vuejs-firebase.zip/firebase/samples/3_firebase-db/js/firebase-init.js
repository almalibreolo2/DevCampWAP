// Initialize Firebase
var config = {
  apiKey: "AIzaSyA7y_ic_AHAp1o_3nXZJCTVmUnPqjXl48I",
  authDomain: "friendlychat-34059.firebaseapp.com",
  databaseURL: "https://friendlychat-34059.firebaseio.com",
  projectId: "friendlychat-34059",
  storageBucket: "friendlychat-34059.appspot.com",
  messagingSenderId: "800635767370"
};
firebase.initializeApp(config);
